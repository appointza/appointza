namespace PlanItNoww.Authentication.Utils
{
    public static class AppConstants
    {
        public const string AccessTokenKey = "token";
    }
}

