using PlanItNoww.Models;
using PlanItNoww.Authentication.Services;
using PlanItNoww.Authentication.Models;
using PlanItNoww.Authentication.Utils;
using PlanItNoww.Utils;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace PlanItNoww.Authentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ILogger<AuthController> logger;
        private readonly AuthService authService;
        private readonly RequestState requestState;

        public AuthController(ILogger<AuthController> logger, AuthService authService, RequestState requestState)
        {
            this.logger = logger;
            this.authService = authService;
            this.requestState = requestState;
        }

        [HttpPost("Register")]
        public async Task<ActionResult<ActionRes<UsersContext>>> Register(ActionReq<RegisterRequest> req)
        {
            ActionRes<UsersContext> result = new ActionRes<UsersContext>();
            try
            {
                result.item = await authService.Register(req.item);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error during registration");
                return BadRequest(new { error = ex.Message, message = "Registration failed" });
            }
            return Ok(result);
        }

        [HttpPost("GetOtp")]
        public async Task<ActionResult<ActionRes<GetOtpResponse>>> GetOtp(ActionReq<GetOtpRequest> req)
        {
            ActionRes<GetOtpResponse> result = new ActionRes<GetOtpResponse>();
            try
            {
                result.item = await authService.GetOtp(req.item);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error getting OTP");
                return BadRequest(new { error = ex.Message, message = "Failed to get OTP" });
            }
            return Ok(result);
        }

        [HttpPost("Login")]
        public async Task<ActionResult<ActionRes<UsersContext>>> Login(ActionReq<LoginRequest> req)
        {
            ActionRes<UsersContext> result = new ActionRes<UsersContext>();
            try
            {
                result.item = await authService.Login(req.item);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error during login");
                return BadRequest(new { error = ex.Message, message = "Login failed" });
            }
            return Ok(result);
        }

        [HttpPost("RefreshToken")]
        public async Task<ActionResult<ActionRes<UsersContext>>> RefreshToken(ActionReq<RefreshTokenRequest> req)
        {
            ActionRes<UsersContext> result = new ActionRes<UsersContext>();
            try
            {
                result.item = await authService.RefreshToken(req.item);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error refreshing token");
                return BadRequest(new { error = ex.Message, message = "Token refresh failed" });
            }
            return Ok(result);
        }

        [HttpGet("ValidateToken")]
        [Authenticate]
        public async Task<ActionResult<ActionRes<UsersContext>>> ValidateToken()
        {
            ActionRes<UsersContext> result = new ActionRes<UsersContext>();
            try
            {
                var userContext = requestState.usercontext;
                if (userContext == null || userContext.userid <= 0)
                {
                    return Unauthorized(new { message = "Unauthorized" });
                }
                result.item = userContext;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error validating token");
                return BadRequest(new { error = ex.Message, message = "Token validation failed" });
            }
            return Ok(result);
        }

        [HttpPost("GoogleLogin")]
        public async Task<ActionResult<ActionRes<UsersContext>>> GoogleLogin(ActionReq<GoogleLoginRequest> req)
        {
            ActionRes<UsersContext> result = new ActionRes<UsersContext>();
            try
            {
                if (req == null)
                {
                    logger.LogError("GoogleLogin request is null");
                    return BadRequest(new { error = "Request is null", message = "Invalid request format" });
                }
                
                if (req.item == null)
                {
                    logger.LogError("GoogleLogin request.item is null");
                    return BadRequest(new { error = "Request item is null", message = "Invalid request format" });
                }
                
                result.item = await authService.GoogleLogin(req.item);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error during Google login");
                return BadRequest(new { error = ex.Message, message = "Google login failed", stackTrace = ex.StackTrace });
            }
            return Ok(result);
        }



        [HttpGet("partner-data")]
        public IActionResult GetPartnerData()
        {
            var company = HttpContext.Items["CallingCompany"]?.ToString();

            if (company != "appointza")
                return Forbid();

            return Ok("Secure data for Appointza");
        }


        [ApiController]
        [Route("api/b2b/partners")]
        public class PartnerController : ControllerBase
        {
            [HttpGet("data")]
            public IActionResult GetData()
            {
                var company = HttpContext.Items["CallingCompany"];
                return Ok($"Called by {company}");
            }
        }


    }
}

